import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddIdeaComponent } from './add-idea/add-idea.component';
import { GetCoinsComponent } from './auth/get-coins/get-coins.component';
import { LoginComponent } from './auth/login/login.component';
import { SignupComponent } from './auth/signup/signup.component';
import { IdeasVIewComponent } from './ideas-view/ideas-view.component';
import { TransactionComponent } from './transaction/transaction.component';

const routes: Routes = [
  {path:'ideatransaction',component:TransactionComponent},
  {path:'addidea',component:AddIdeaComponent},
  {path:'viewIdeas',component:IdeasVIewComponent},
  {path:'login',component:LoginComponent},
  {path:'signup',component:SignupComponent},
  {path:'getcoins',component:GetCoinsComponent},
  {path:'**', redirectTo:'/login'},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
