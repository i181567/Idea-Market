var CentralNode = {
  "IP":"localhost",
  "PORT":"3000"
}
export default CentralNode;
