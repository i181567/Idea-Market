import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import BlockData from './models/BlockData.model';
import CentralNode from './CentralNode';
@Injectable({
  providedIn: 'root'
})
export class ChainService {
  public blockChain: BlockData[] = [];

  constructor(private http: HttpClient) {
    this.loadBlockChain();
  }
  loadBlockChain() {
    return this.http.get<any>('http://localhost:8081/listideas', { responseType: 'json' })
  }
  populateBlockchain() {
    this.loadBlockChain().toPromise()
      .then(
        data => {
          console.log(data);
          data.forEach((element: BlockData) => {
            this.blockChain.push(element);
          });
          console.log(this.blockChain);
        }
      )
  }
  getBlockChain() {
    return this.blockChain;
  }
  addNewItem(block: BlockData) {
    // Add here your data
    //right now just adding the data in the blockchain so delete this line later
    //this.blockChain.push(block);

    //  you are to uncomment this code and work here
    this.http.post(`http://localhost:8081/proposeidea`,block)
    .toPromise()
    .then(_ => {
      console.log(_);
      this.loadBlockChain();
    })
    .catch(_ => {
      alert("Error while proposing idea check console");
      console.log(_);
    })
  }
  deleteBlock() {

  }
  ApproveAndMine() {

  }
}
/**
 * {t4 d4 [o4] p4 d4 [t4] 50 500 [500]}
 */
