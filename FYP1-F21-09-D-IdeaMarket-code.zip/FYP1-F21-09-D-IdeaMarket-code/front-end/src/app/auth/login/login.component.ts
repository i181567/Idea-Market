import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public passwordToggler: string = "show"
  @ViewChild('passInputField') passInputField: ElementRef = new ElementRef('passInputField');

  constructor(public authSrvs:AuthService) { }

  ngOnInit(): void {
  }

  public togglePassVisibilty(){
    if (this.passwordToggler === "show") {
      this.passwordToggler = "hide"
      this.passInputField.nativeElement.type = "text"
    }else{
      this.passwordToggler = "show"
      this.passInputField.nativeElement.type = "password"
    }
  }
}
