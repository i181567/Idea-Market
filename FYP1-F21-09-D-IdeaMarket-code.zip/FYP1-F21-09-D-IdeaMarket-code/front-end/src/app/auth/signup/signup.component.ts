import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import User from '../User.model';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  public signUpUser: User = {
    password:"",
    publicAddress:"",
    username:""
  }
  public verifyPass:string = "";
  constructor(private auth:AuthService,public router:Router) { }

  ngOnInit(): void {
  }

  signUp(){
    this.auth.signUp(this.signUpUser);
    this.router.navigateByUrl('/signin');
  }
}
