interface User {
  username: string,
  publicAddress: string,
  password:string
}
export default User;
