import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import User from './User.model';
import CentralNode from '../CentralNode';
import {SHA256} from 'crypto-js';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  public usersList: User[] = [
    // {
    //   username:"abubakar",
    //   password:"1234",
    //   publicAddress:"xskdbaudi86"
    // },
  ]
  private loggedIn:boolean = false;
  public activeUser:User = {
    username:"",
    password:"",
    publicAddress:""
  }
  constructor(private router:Router,private http:HttpClient) { }

  public loginUser(username:string, password:string){
    this.loggedIn = false;
    this.usersList.forEach(element => {
      if(element.username === username && SHA256(element.password).toString() === password){
        alert("Logged in successfully")
        this.loggedIn = true;
        this.router.navigateByUrl('/viewIdeas')
      }
    });
    if(!this.isLoggedIn()){
      alert("Invalid User or credentials")
    }
    return this.isLoggedIn();
  }

  public isLoggedIn():boolean{
    return this.loggedIn;
  }

  public signOut(){
    this.activeUser = {
      username :"",
      password:"",
      publicAddress:""
    }
    this.loggedIn = false
  }

  public signUp(user:User){
    user.password = SHA256(user.password).toString();
    user.publicAddress = SHA256(user.username).toString();
    this.usersList.push(user)
    console.log(this.usersList);

    //uncomment this code to work with it wasif and comment the line where the use is pushed in list
    // this.http.post(`http://${CentralNode.IP}:${CentralNode.PORT}/signup`,user)
    // .toPromise()
    // .then(_ => {
    //   //response
    //   console.log(_);
    // })
    // .catch(_ => {
    //   console.log(_);
    //   alert("Cannot Sign you up right now")
    // })
  }
}
