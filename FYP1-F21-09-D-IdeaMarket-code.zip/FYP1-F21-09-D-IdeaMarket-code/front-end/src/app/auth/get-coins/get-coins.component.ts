import { Component, OnInit } from '@angular/core';
import { CoinsService } from 'src/app/coins.service';

@Component({
  selector: 'app-get-coins',
  templateUrl: './get-coins.component.html',
  styleUrls: ['./get-coins.component.css']
})
export class GetCoinsComponent implements OnInit {

  constructor(public coinSrvs:CoinsService) { }

  ngOnInit(): void {
  }
}
