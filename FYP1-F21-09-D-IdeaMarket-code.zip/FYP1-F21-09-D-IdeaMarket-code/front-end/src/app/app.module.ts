import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TransactionComponent } from './transaction/transaction.component';
import { NavbarComponent } from './navbar/navbar.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AddIdeaComponent } from './add-idea/add-idea.component';
import { FooterComponent } from './footer/footer.component';
import { IdeaItemComponent } from './idea-item/idea-item.component';
import { IdeasVIewComponent } from './ideas-view/ideas-view.component';
import { SignupComponent } from './auth/signup/signup.component';
import { LoginComponent } from './auth/login/login.component';
import { GetCoinsComponent } from './auth/get-coins/get-coins.component';

@NgModule({
  declarations: [
    AppComponent,
    TransactionComponent,
    NavbarComponent,
    AddIdeaComponent,
    FooterComponent,
    IdeaItemComponent,
    IdeasVIewComponent,
    SignupComponent,
    LoginComponent,
    GetCoinsComponent
  ],
  imports: [
    HttpClientModule,
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
