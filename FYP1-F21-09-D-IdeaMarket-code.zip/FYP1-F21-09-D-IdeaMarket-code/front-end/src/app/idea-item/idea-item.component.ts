import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-idea-item',
  templateUrl: './idea-item.component.html',
  styleUrls: ['./idea-item.component.css']
})
export class IdeaItemComponent implements OnInit {
  @Input('Title') Title:string = "Title";
  @Input('Description') Description:string = "Description";
  @Input('Owners') Owners:string[] = ["Generic Owner 1","Generic Owner 2"];
  @Input('Problem') Problem: string = "Problem";
  @Input('Domain') Domain:string = "Domain";
  @Input('Technologies_used') Technologies_used:string[] = ["Generic tech 1","Generic Tech 2"];
  @Input('Viewing_price') Viewing_price: number = 100;
  @Input('Ownership_price') Ownership_price: number = 100;
  @Input('Pricing_history') Pricing_history: number[] = [100,200,300];




  constructor() { }

  ngOnInit(): void {

  }

}


/**
 * {Title2 Description2 [Owner2] Problem2 Description2 [Tech2] 20 200 [200]}{Title1 Description1 [Owner1] Problem1 Description1 [Tech1] 10 100 [100]}{Title3 Description3 [Owner3] Problem3 Description3 [Technology3] 30 300 [300]}{t4 d4 [o4] p4 d4 [t4] 50 500 [500]}
 */
