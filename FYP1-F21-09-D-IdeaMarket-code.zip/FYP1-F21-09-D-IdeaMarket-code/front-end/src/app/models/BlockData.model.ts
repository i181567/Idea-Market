interface BlockData {
  Description: string,
  Domain: string,
  Owners: string[],
  Ownership_price: number,
  Pricing_history: number[]
  Problem: string,
  Technologies_used: string[]
  Title: string,
  Viewing_price: number

}
export default BlockData;


/**
 * Title2 Description2 [Owner2] Problem2 Description2 [Tech2] 20 200 [200]
 */
