import { ElementRef, Injectable, ViewChild } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CoinsService {
  public coins: number = 0;
  private exchangeRateInPKR:number = 10;
  public coinsToAdd:number = 0
  constructor() { }

  addCoins(){
    this.coins += this.coinsToAdd;
    this.coinsToAdd = 0;
  }

  getExchangeRateInPKR(){
    return this.exchangeRateInPKR*this.coinsToAdd;
  }

}
