import { Component, OnInit } from '@angular/core';
import { ChainService } from '../chain.service';
import BlockData from '../models/BlockData.model';

@Component({
  selector: 'app-add-idea',
  templateUrl: './add-idea.component.html',
  styleUrls: ['./add-idea.component.css']
})
export class AddIdeaComponent implements OnInit {
  public newIdea: BlockData = {
    Title:"",
    Description:"",
    Domain:"",
    Owners:[],
    Ownership_price:0,
    Pricing_history:[],
    Problem:"",
    Technologies_used:[],
    Viewing_price:0
  }
  constructor(private chain: ChainService) { }

  ngOnInit(): void {
  }

  addBlock(){
    this.chain.addNewItem(this.newIdea)
  }
}
