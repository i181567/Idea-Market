import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth/auth.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  public isMenuCollapsed: boolean = false;
  constructor(private router: Router, private authSrvs: AuthService) { }

  ngOnInit(): void {
  }

  onLoginClicked(){
    if(this.authSrvs.loginUser(this.authSrvs.activeUser.username,this.authSrvs.activeUser.password)){
      this.router.navigateByUrl('/viewIdeas')
    }else{
      alert("Invalid username or password")
    }

  }
  onSignUpClicked(){
    this.router.navigateByUrl('/signup')
  }
  onSignOutClicked(){
    this.authSrvs.signOut();
    this.router.navigateByUrl('/login')
  }
  isLoggedIn(){
    return this.authSrvs.isLoggedIn();
  }


}
