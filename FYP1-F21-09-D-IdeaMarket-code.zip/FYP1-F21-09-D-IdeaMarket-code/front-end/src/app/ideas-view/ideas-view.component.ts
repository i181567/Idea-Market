import { Component, OnInit } from '@angular/core';
import { ChainService } from '../chain.service';
import BlockData from '../models/BlockData.model';

@Component({
  selector: 'app-ideas-view',
  templateUrl: './ideas-view.component.html',
  styleUrls: ['./ideas-view.component.css']
})
export class IdeasVIewComponent implements OnInit {

  // public blockChain: BlockData[] = [];
  constructor(public blkChnSrvs: ChainService) { }

  ngOnInit(): void {
    this.loadBlockChain();
  }
  loadBlockChain(){
    this.blkChnSrvs.populateBlockchain();
    // this.blkChnSrvs.loadBlockChain().toPromise()
    // .then(data => {
    //   console.log(data);
    //   // this.blockChain = data
    //   data.forEach((element: BlockData) => {
    //     this.blockChain.push(element);
    //   });
    //   console.log(this.blockChain);
    // })
    // .catch(_ => {
    //   console.log(_);

    // });
    // console.log(this.blockChain);
  }

}
