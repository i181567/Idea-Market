import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IdeasVIewComponent } from './ideas-view.component';

describe('IdeasVIewComponent', () => {
  let component: IdeasVIewComponent;
  let fixture: ComponentFixture<IdeasVIewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ IdeasVIewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(IdeasVIewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
